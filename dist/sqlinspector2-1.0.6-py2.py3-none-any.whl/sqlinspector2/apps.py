from django.apps import AppConfig


class SqlinspectorConfig(AppConfig):
    name = 'sqlinspector2'
